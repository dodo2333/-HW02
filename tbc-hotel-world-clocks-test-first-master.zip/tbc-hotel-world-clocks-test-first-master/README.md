tbc-hotel-world-clocks-test-first
=================================

Kata Hotel World Clocks developed in TDD for my book Taming the Bad Code
